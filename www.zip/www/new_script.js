        document.addEventListener("DOMContentLoaded", () => {
            const formOpenBtn = document.getElementById("form-open"),
                formCloseBtn = document.querySelector(".form_close"),
                signupBtn = document.getElementById("signup"),
                loginBtn = document.getElementById("login"),
                formContainer = document.querySelector(".form_container"),
                loginForm = document.querySelector(".login_form"),
                signupForm = document.querySelector(".signup_form");

            formOpenBtn.addEventListener("click", () => {
                formContainer.classList.add("show");
            });

            formCloseBtn.addEventListener("click", () => {
                formContainer.classList.remove("show");
            });

            signupBtn.addEventListener("click", (e) => {
                e.preventDefault();
                loginForm.style.display = "none";
                signupForm.style.display = "block";
            });

            loginBtn.addEventListener("click", (e) => {
                e.preventDefault();
                signupForm.style.display = "none";
                loginForm.style.display = "block";
            });

            document.getElementById('uploadForm').addEventListener('submit', function(event) {
                event.preventDefault(); // Отмена отправки формы

                var formdata = new FormData(this); // Получение данных формы

                formdata.append("api_key", "<YOUR_API_KEY>"); // Добавление API ключа
                formdata.append("country_code", "kz"); // Добавление кода страны

                var requestOptions = {
                    method: 'POST',
                    body: formdata,
                    redirect: 'follow'
                };

                fetch("https://kyc.biometric.kz/api/v1/backend/document/parse/", requestOptions)
                    .then(response => response.text())
                    .then(result => console.log(result))
                    .catch(error => console.log('error', error));
            });
        });